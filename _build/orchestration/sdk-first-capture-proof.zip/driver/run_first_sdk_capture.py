"""One separately authorized owned IPv4 SDK capture; no worker cohort or full gate."""

import hashlib
import json
from pathlib import Path
import sys

REPO = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(REPO))

from tests.contract.owned_content_response_worker_launcher import Build, RetainSourceFinal
from tests.contract.owned_content_response_target import OwnedContentResponseTarget
from tests.contract.owned_content_response_product_runner import (
    AssertContentInstallation, AssertContentSourceFacts,
)
from tests.contract.owned_content_response_sdk_oracle import AssertContentParts
from tests.contract.owned_content_response_sdk_state_oracle import AssertSdkSaveTransition
from tests.native_crawl_acceptance_helpers import NativeCaseEvidence, NativeEnvironment, NativeProcess

COMMIT = "b1042606485fdab0fdb603cc8ff287f177a7e071"
TREE = "624ec4ea8dca1c9cdcdeb52a374aadabf20025f7"
ROOT = REPO / "_build/content-sdk-first-capture-20261024T1548"
ROOT.mkdir(parents=True, exist_ok=False)
OWNER = "actor:owned-response-product"
WORKSPACE_ID = "owned-response-product"
CASE = "missing"
ENTRY = REPO / "tests/contract/owned_content_response_sdk_entrypoint.py"
evidence = NativeCaseEvidence(ROOT / "originals", ROOT / "retained")
expected_helpers = {path.name: hashlib.sha256(path.read_bytes()).hexdigest()
    for path in (REPO / "tests/contract").glob("owned_content_response_sdk_*.py")}
expected_helpers["owned_response_product_runner.py"] = hashlib.sha256(
    (REPO / "tests/contract/owned_response_product_runner.py").read_bytes()).hexdigest()
print(json.dumps({"step": "one-offline-build", "commit": COMMIT, "tree": TREE}), flush=True)
installed = Build(REPO, ROOT / "installation", evidence, commit=COMMIT, tree=TREE, enabled=True)
environment = NativeEnvironment(ROOT / "launch-state")
workspace = ROOT / "workspace"


def Operation(operation, selection):
    """Retain fixed subprocess originals before any success or JSON interpretation."""

    input_path = ROOT / (operation + "-input.json")
    observations = ROOT / (operation + "-observations")
    raw = json.dumps({"selection": selection, "observations": str(observations)},
        sort_keys=True, separators=(",", ":"), allow_nan=False).encode("ascii")
    input_path.write_bytes(raw)
    evidence.Write(operation + "-input.json", raw)
    result = NativeProcess(evidence, "sdk-" + operation,
        (str(installed.python), "-I", "-B", str(ENTRY), operation, str(input_path), "--execute"),
        cwd=ROOT, environment=environment, timeout=30, maximum=8 * 1024 * 1024,
        installation=installed.installation)
    assert result.returncode == 0, "Actual SDK operation failed; original terminal records retained"
    document = json.loads(result.stdout)
    AssertContentInstallation(installed.installation["identity"], document["installed_identity"],
        commit=COMMIT, tree=TREE)

    for name, observed in document["consumer_sources"].items():
        assert observed["sha256"] == expected_helpers[name]
        assert Path(observed["path"]) == REPO / "tests/contract" / name

    print(json.dumps({"step": operation, "returncode": result.returncode}), flush=True)

    return document


main = NativeCaseEvidence(ROOT / "main", ROOT / "main-retained")
sentinel = NativeCaseEvidence(ROOT / "sentinel", ROOT / "sentinel-retained")

try:
    with OwnedContentResponseTarget(main, address="127.0.0.1", case=CASE) as target:
        with OwnedContentResponseTarget(sentinel, address="127.0.0.1", case=CASE) as other:
            url = target.graph.Url("/research/content")
            sentinel_origin = other.graph.origin
            setup = Operation("setup", {"workspace": str(workspace), "url": url,
                "owner_reference": OWNER})
            before = setup["summary"]["original_setup"]["original_setup"]
            capture = Operation("capture", {"workspace": str(workspace), "scope_id": "owned-source",
                "url": url, "owner_reference": OWNER, "policy": setup["summary"]["policies"][
                    "acquisition"]["path"], "approve_safe_content_response_capture": True,
                "retain_response": True})
            inspection = Operation("inspect", {"workspace": str(workspace)})

finally:
    finals = RetainSourceFinal(evidence, {"main": main, "sentinel": sentinel})
    for operation in ("setup", "capture", "inspect"):
        directory = ROOT / (operation + "-observations")

        if directory.exists():
            for path in directory.glob("*.json"):
                evidence.Write(operation + "/" + path.name, path.read_bytes())

after = inspection["summary"]["original_inspection"]
summary = capture["summary"]
observation = json.loads((ROOT / "capture-observations/capture.json").read_bytes())
AssertSdkSaveTransition(before, after, summary, observation["store_saves"], url=url,
    workspace_id=WORKSPACE_ID, scope_reference="scope:owned-source")
AssertContentParts(CASE, url, summary["original_receipt_id"], after["originals"],
    summary["source_facts"], job_id=summary["original_job_id"])
delivery = AssertContentSourceFacts(CASE, url, finals["main"], finals["sentinel"],
    sentinel_origin=sentinel_origin)
assert len(observation["executions"]) == 1, "One actual governed worker execution is required"
verdict = {"identity": "sdk:ipv4:missing:original-save-ack", "status": "passed",
    "commit": COMMIT, "tree": TREE, "summary": summary, "source_delivery": delivery,
    "save_owners": [row["owner"] for row in observation["store_saves"]],
    "source_contacts": {"main": 1, "sentinel": 0}, "runtime_root": str(ROOT),
    "limits": "One SDK capture only; authority-negative/header-v2/replay/CLI/IPv6/fullCI UNRUN"}
evidence.Json("verdict.json", verdict)
print(json.dumps(verdict), flush=True)
