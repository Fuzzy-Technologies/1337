"""Fixed separately reviewed installed child for one offline Analyze or historical Replay."""

import hashlib
import json
from pathlib import Path
import sys
from types import ModuleType

REPO = Path(__file__).resolve().parents[2]
DIRECTORY = REPO / "tests/contract"


def Load(name):
    """Execute only bounded exact fixed helper bytes and retain their original identity."""

    assert name in {"owned_content_response_sdk_entrypoint.py",
        "owned_content_response_sdk_consumer.py", "owned_content_response_sdk_offline_guard.py",
        "owned_response_product_runner.py"}
    path = DIRECTORY / name
    with path.open("rb") as stream:
        raw = stream.read(1048577)
    assert len(raw) <= 1048576
    module = ModuleType("fixed_header_" + name[:-3])
    module.__file__ = str(path)
    exec(compile(raw, str(path), "exec"), module.__dict__)
    return module, {"path": str(path), "sha256": hashlib.sha256(raw).hexdigest()}


def Main():
    """Run exactly the selected existing-source operation with retained forbidden-call facts."""

    assert sys.flags.isolated and sys.flags.dont_write_bytecode
    assert len(sys.argv) == 3 and sys.argv[1] in ("analyze", "replay")
    operation = sys.argv[1]
    entry, entry_source = Load("owned_content_response_sdk_entrypoint.py")
    config = entry.ReadInput(Path(sys.argv[2]))
    identity = entry.Identity()
    modules = {}
    sources = {"owned_content_response_sdk_entrypoint.py": entry_source}
    for name in ("owned_content_response_sdk_consumer.py",
        "owned_content_response_sdk_offline_guard.py", "owned_response_product_runner.py"):
        modules[name], sources[name] = Load(name)
    consumer = modules["owned_content_response_sdk_consumer.py"]
    guards = modules["owned_content_response_sdk_offline_guard.py"]
    seed = modules["owned_response_product_runner.py"]
    observations = Path(config["observations"])
    workspace = Path(config["selection"]["workspace"])
    assert observations.is_absolute() and workspace.is_absolute()
    assert not observations.resolve().is_relative_to(workspace.resolve())
    assert not workspace.resolve().is_relative_to(observations.resolve())
    metrics_directory = observations.with_name(observations.name + "-guard")
    assert not metrics_directory.resolve().is_relative_to(workspace.resolve())
    assert not workspace.resolve().is_relative_to(metrics_directory.resolve())
    metrics_directory.mkdir(parents=True, exist_ok=False)
    before = after = summary = record = None
    exception_type = None
    try:
        with guards.OfflineGuard(historical=operation == "replay", enabled=True) as record:
            before = seed.Inspect(workspace)
            summary = (consumer.Analyze(config["selection"], observations, enabled=True) if (
                operation == "analyze") else consumer.Replay(config["selection"], observations,
                    enabled=True))
            after = seed.Inspect(workspace)
    except BaseException as error:
        exception_type = type(error).__name__
        raise
    finally:
        document = {"operation": operation, "installed_identity": identity,
            "helper_sources": sources, "before": before, "after": after, "summary": summary,
            "guard": None if record is None else guards.DetachedGuard(record),
            "exception_type": exception_type}
        raw = json.dumps(document, sort_keys=True, separators=(",", ":"), ensure_ascii=True,
            allow_nan=False).encode("ascii")
        assert len(raw) <= 8 * 1024 * 1024
        with (metrics_directory / "original-observations.json").open("xb") as output:
            output.write(raw)
    assert document["guard"]["audit_probe_seen"] is True
    assert all(value == 0 for value in document["guard"]["calls"].values())
    sys.stdout.buffer.write(raw)
    sys.stdout.buffer.flush()
    return 0


if __name__ == "__main__":
    raise SystemExit(Main())
