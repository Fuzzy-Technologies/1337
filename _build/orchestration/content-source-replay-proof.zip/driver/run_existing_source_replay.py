"""One separately authorized historical SOURCE replay only; no Analyze or header replay."""

import hashlib
import json
from pathlib import Path
import shutil
import sys

REPO = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(REPO))

from tests.contract.owned_content_response_product_runner import AssertContentInstallation
from tests.contract.owned_content_response_sdk_oracle import AssertContentParts, Canonical
from tests.native_crawl_acceptance_helpers import NativeCaseEvidence, NativeEnvironment
from tests.native_crawl_acceptance_helpers import NativeInstallation, NativeProcess

OLD = REPO / "_build/content-sdk-first-capture-20261024T1548"
ROOT = REPO / "_build/content-source-replay-existing-20261024T1621"
SOURCE_COMMIT = "b1042606485fdab0fdb603cc8ff287f177a7e071"
SOURCE_TREE = "624ec4ea8dca1c9cdcdeb52a374aadabf20025f7"
HELPER_COMMIT = "9986c922e2746509ef96ab90094b45c19486c1c9"
HELPER_TREE = "e0dc9a536b9c03b1ed8b7b28bbed397088490391"
python = OLD / "installation/environment/bin/python"
installation = NativeInstallation(python)
assert installation["identity"]["source_commit"] == SOURCE_COMMIT
assert installation["identity"]["source_tree"] == SOURCE_TREE
original = json.loads((OLD / "originals/verdict.json").read_bytes())
summary = original["summary"]
assert original["identity"] == "sdk:ipv4:missing:original-save-ack" and original["status"] == "passed"
url = json.loads((OLD / "capture-input.json").read_bytes())["selection"]["url"]
workspace = OLD / "workspace"
relocated = OLD / "workspace-relocated-source-replay"
assert workspace.is_dir() and not relocated.exists()
ROOT.mkdir(parents=True, exist_ok=False)
evidence = NativeCaseEvidence(ROOT / "originals", ROOT / "retained")
environment = NativeEnvironment(ROOT / "launch-state")
child = REPO / "_build/orchestration/run_existing_header_v2_child.py"
helper_names = ("owned_content_response_sdk_entrypoint.py", "owned_content_response_sdk_consumer.py",
    "owned_content_response_sdk_offline_guard.py", "owned_response_product_runner.py")
hashes = {
    "owned_content_response_sdk_entrypoint.py":
        "7337c480935af66a22e07780da77e59145e4bad3fa8648638cae337dc9bdb968",
    "owned_content_response_sdk_consumer.py":
        "853b7aed0c424a44eeb194ba962c44892f19020f0d19d11f2146a1e73814524e",
    "owned_content_response_sdk_offline_guard.py":
        "578d17fc0a61af306b1ca4f650768a1023bac1df5853951cebe823c7fd4367ae",
    "owned_response_product_runner.py":
        "7143b1b509fc81252fd3c78922ce71978d2b5502d357a3e04e0aef1336f59f55"}
assert all(hashlib.sha256((REPO / "tests/contract" / name).read_bytes()).hexdigest() == hashes[name]
    for name in helper_names), "Helper bytes must match the independently reviewed immutable Git blobs"
assert hashlib.sha256(child.read_bytes()).hexdigest() == (
    "c6fbd95e7ab8a328ac4c853a9d9dd79576dfc4045f0172ddeb1bb567b25323d8")
evidence.Json("selection.json", {"identity": "sdk:source-replay:relocated-original",
    "operation": "replay", "kind": "source", "source_commit": SOURCE_COMMIT,
    "source_tree": SOURCE_TREE, "helper_commit": HELPER_COMMIT, "helper_tree": HELPER_TREE,
    "original_receipt_id": summary["original_receipt_id"], "original_workspace": str(workspace),
    "relocated_workspace": str(relocated), "child_sha256": hashlib.sha256(child.read_bytes()).hexdigest()})
shutil.move(str(workspace), relocated)
assert not workspace.exists() and relocated.is_dir()
config = {"selection": {"workspace": str(relocated), "kind": "source",
    "reference": summary["original_receipt_id"]}, "observations": str(ROOT / "replay-observations")}
input_path = ROOT / "replay-input.json"
raw = json.dumps(config, sort_keys=True, separators=(",", ":"), allow_nan=False).encode("ascii")
input_path.write_bytes(raw)
evidence.Write("replay-input.json", raw)

try:
    result = NativeProcess(evidence, "source-replay", (str(python), "-I", "-B", str(child),
        "replay", str(input_path)), cwd=ROOT, environment=environment, timeout=30,
        maximum=8 * 1024 * 1024, installation=installation)

finally:
    for directory in (ROOT / "replay-observations", ROOT / "replay-observations-guard"):
        if directory.exists():
            for path in directory.glob("*.json"):
                evidence.Write(directory.name + "/" + path.name, path.read_bytes())

assert result.returncode == 0, "Historical replay failed; originals retained, no retry"
document = json.loads(result.stdout)
AssertContentInstallation(installation["identity"], document["installed_identity"],
    commit=SOURCE_COMMIT, tree=SOURCE_TREE)
assert set(document["helper_sources"]) == set(helper_names)
assert all(document["helper_sources"][name]["sha256"] == hashes[name] for name in helper_names)
assert document["guard"]["audit_probe_seen"] is True
assert all(value == 0 for value in document["guard"]["calls"].values())
assert document["guard"]["saves"] == [] and document["exception_type"] is None
assert Canonical(document["before"]) == Canonical(document["after"])
replay = document["summary"]
assert replay["state"] == "verified" and replay["workflow"] == "owned-content-response-replay"
assert replay["source_id"] == "native.loopback-content-response"
for key in ("original_job_id", "original_receipt_id", "original_role_ids", "source_facts",
    "model_revision", "workspace_revision"):
    assert Canonical(replay[key]) == Canonical(summary[key])
AssertContentParts("missing", url, replay["original_receipt_id"], document["after"]["originals"],
    replay["source_facts"], job_id=replay["original_job_id"])
verdict = {"identity": "sdk:source-replay:relocated-original", "status": "passed",
    "installed_component_commit": SOURCE_COMMIT, "installed_component_tree": SOURCE_TREE,
    "helper_commit": HELPER_COMMIT, "helper_tree": HELPER_TREE, "summary": replay,
    "original_root_absent": not workspace.exists(), "relocated_workspace": str(relocated),
    "forbidden_calls": document["guard"]["calls"], "audit_probe_seen": True,
    "save_calls": 0, "limits": "SOURCE replay only; Analyze/headerReplay/authoritynegatives/fullCI UNRUN"}
evidence.Json("verdict.json", verdict)
print(json.dumps({key: value for key, value in verdict.items() if key != "summary"}), flush=True)
